"""
Model Manager: lazy-loads HuggingFace models on demand.
Caches loaded models in memory to avoid reloading.
Designed for 4GB RAM machines — uses CPU inference with int8 where possible.
"""

import os
import json
import logging
from typing import Optional, Dict, Any

logger = logging.getLogger("ModelManager")

# Global cache: model_id -> (tokenizer, model)
_model_cache: Dict[str, Any] = {}


def _load_model(model_id: str):
    """Load a model and tokenizer from HuggingFace (downloads if not cached locally)."""
    if model_id in _model_cache:
        return _model_cache[model_id]

    try:
        from transformers import AutoTokenizer, AutoModelForCausalLM
        import torch

        logger.info(f"Loading model: {model_id}")
        cache_dir = os.path.join(os.path.dirname(__file__), "..", "models", "cache")
        os.makedirs(cache_dir, exist_ok=True)

        tokenizer = AutoTokenizer.from_pretrained(
            model_id,
            cache_dir=cache_dir,
            use_fast=True
        )

        # Load in low-memory mode: CPU + float32 (no GPU required)
        model = AutoModelForCausalLM.from_pretrained(
            model_id,
            cache_dir=cache_dir,
            torch_dtype=torch.float32,
            low_cpu_mem_usage=True,
            device_map="cpu"
        )
        model.eval()

        _model_cache[model_id] = (tokenizer, model)
        logger.info(f"Model loaded: {model_id}")
        return tokenizer, model

    except Exception as e:
        logger.error(f"Failed to load model {model_id}: {e}")
        raise


def generate_text(model_id: str, prompt: str, max_new_tokens: int = 512,
                  temperature: float = 0.3) -> str:
    """
    Generate text using the specified local model.
    Returns the generated text (excluding the prompt).
    """
    try:
        import torch
        tokenizer, model = _load_model(model_id)

        inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=1024)
        input_ids = inputs["input_ids"]

        with torch.no_grad():
            outputs = model.generate(
                input_ids,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                do_sample=temperature > 0,
                pad_token_id=tokenizer.eos_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )

        # Decode only the newly generated tokens
        new_tokens = outputs[0][input_ids.shape[1]:]
        result = tokenizer.decode(new_tokens, skip_special_tokens=True)
        return result.strip()

    except Exception as e:
        logger.error(f"Generation error with model {model_id}: {e}")
        # Fallback: return a structured error message the agent can handle
        return f"[MODEL_ERROR: {str(e)}]"


def list_cached_models() -> list:
    """Return list of models currently downloaded in local cache."""
    cache_dir = os.path.join(os.path.dirname(__file__), "cache")
    if not os.path.exists(cache_dir):
        return []
    models = []
    for item in os.listdir(cache_dir):
        full_path = os.path.join(cache_dir, item)
        if os.path.isdir(full_path):
            size_bytes = sum(
                os.path.getsize(os.path.join(dp, f))
                for dp, dn, filenames in os.walk(full_path)
                for f in filenames
            )
            models.append({
                "name": item,
                "path": full_path,
                "size_mb": round(size_bytes / (1024 * 1024), 1)
            })
    return models


def evict_model(model_id: str):
    """Remove a model from the in-memory cache to free RAM."""
    if model_id in _model_cache:
        del _model_cache[model_id]
        logger.info(f"Evicted model from cache: {model_id}")


def loaded_models() -> list:
    """Return list of currently loaded model IDs."""
    return list(_model_cache.keys())
