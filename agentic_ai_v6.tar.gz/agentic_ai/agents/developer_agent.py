"""
Developer Agent: writes real Python files to the workspace directory.
Respects workspace boundaries — will not write outside the assigned workspace.
"""

import os
import re
import json
from typing import Any, Dict
from agents.base_agent import BaseAgent


DEV_PROMPT_TEMPLATE = """<|system|>
You are a senior Python developer. Write complete, working Python code.
Output ONLY a JSON object with two keys: "filename" (relative path) and "code" (full file content).
No explanation. No markdown. Only valid JSON.
<|user|>
Task: {task_description}
Workspace directory: {workspace}

Write a Python file that fulfills this task. Output JSON only:
{{"filename": "relative/path/to/file.py", "code": "# full python code here..."}}
<|assistant|>
"""


class DeveloperAgent(BaseAgent):
    def __init__(self, config: Dict, memory_store=None, workspace: str = "workspace"):
        super().__init__("Developer", config, memory_store)
        self.workspace = os.path.abspath(workspace)
        os.makedirs(self.workspace, exist_ok=True)

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        task_id = task.get("task_id", "unknown")
        goal_id = task.get("goal_id", "unknown")
        description = task.get("description", "")

        self._log_action("dev_start", {"task": description}, goal_id=goal_id, task_id=task_id)

        prompt = DEV_PROMPT_TEMPLATE.format(
            task_description=description,
            workspace=self.workspace
        )
        raw_output = self._generate(prompt)

        result = self._write_file(raw_output, description)
        self._log_action("dev_complete", result, goal_id=goal_id, task_id=task_id)

        return result

    def _write_file(self, raw: str, description: str) -> Dict:
        """Parse model output and write the file to workspace."""
        filename = None
        code = None

        # Try JSON parse
        match = re.search(r'\{.*\}', raw, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(0))
                filename = data.get("filename", "")
                code = data.get("code", "")
            except (json.JSONDecodeError, KeyError):
                pass

        # Fallback: extract Python code block
        if not code:
            code_match = re.search(r'```python\n(.*?)```', raw, re.DOTALL)
            if code_match:
                code = code_match.group(1)
                filename = "output.py"

        # Final fallback: generate minimal implementation
        if not code:
            self.logger.warning("Could not parse developer output. Generating stub.")
            filename = "implementation.py"
            code = f'# Auto-generated stub for: {description}\n\ndef main():\n    """TODO: implement {description}"""\n    pass\n\nif __name__ == "__main__":\n    main()\n'

        if not filename:
            filename = "output.py"

        # Sanitize path — ensure it stays within workspace
        safe_path = self._safe_path(filename)
        if safe_path is None:
            return {
                "status": "error",
                "error": f"Attempted to write outside workspace: {filename}"
            }

        os.makedirs(os.path.dirname(safe_path), exist_ok=True)
        with open(safe_path, "w", encoding="utf-8") as f:
            f.write(code)

        self.logger.info(f"Written: {safe_path}")
        return {
            "status": "success",
            "file_path": safe_path,
            "filename": filename,
            "lines": len(code.splitlines())
        }

    def _safe_path(self, relative_path: str) -> str:
        """Return absolute path only if it's inside workspace. Otherwise return None."""
        # Strip leading slashes and normalize
        clean = relative_path.lstrip("/").replace("..", "")
        abs_path = os.path.normpath(os.path.join(self.workspace, clean))
        if abs_path.startswith(self.workspace):
            return abs_path
        return None
