"""
Planner Agent: decomposes high-level goals into structured task graphs.
Never writes code. Outputs JSON task lists only.
"""

import json
import re
from typing import Any, Dict, List
from agents.base_agent import BaseAgent


PLANNER_PROMPT_TEMPLATE = """<|system|>
You are a software project planner. Your job is to decompose a goal into concrete development tasks.
You NEVER write code. You ONLY output a JSON list of tasks.
Each task must have: id, description, agent (one of: developer, reviewer, qa), dependencies (list of task ids).
Keep tasks atomic and specific. Output ONLY valid JSON, no explanation.
<|user|>
Goal: {goal}

Output a JSON array of tasks like:
[
  {{"id": "t1", "description": "...", "agent": "developer", "dependencies": []}},
  {{"id": "t2", "description": "...", "agent": "reviewer", "dependencies": ["t1"]}},
  {{"id": "t3", "description": "...", "agent": "qa", "dependencies": ["t2"]}}
]
<|assistant|>
"""


class PlannerAgent(BaseAgent):
    def __init__(self, config: Dict, memory_store=None):
        super().__init__("Planner", config, memory_store)

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        goal = task.get("goal", "")
        goal_id = task.get("goal_id", "unknown")

        self._log_action("planning_start", {"goal": goal}, goal_id=goal_id)

        prompt = PLANNER_PROMPT_TEMPLATE.format(goal=goal)
        raw_output = self._generate(prompt)

        tasks = self._parse_tasks(raw_output, goal)

        self._log_action("planning_complete", {"tasks_count": len(tasks), "tasks": tasks}, goal_id=goal_id)

        return {
            "status": "success",
            "tasks": tasks,
            "raw_output": raw_output
        }

    def _parse_tasks(self, raw: str, goal: str) -> List[Dict]:
        """Extract JSON task list from model output. Falls back to a default plan if parsing fails."""
        # Try to find a JSON array in the output
        match = re.search(r'\[.*?\]', raw, re.DOTALL)
        if match:
            try:
                tasks = json.loads(match.group(0))
                if isinstance(tasks, list) and len(tasks) > 0:
                    return tasks
            except json.JSONDecodeError:
                pass

        # Fallback: generate a sensible default task plan
        self.logger.warning("Could not parse model output as JSON tasks. Using default plan.")
        return [
            {"id": "t1", "description": f"Implement: {goal}", "agent": "developer", "dependencies": []},
            {"id": "t2", "description": f"Review implementation of: {goal}", "agent": "reviewer", "dependencies": ["t1"]},
            {"id": "t3", "description": f"Write and run tests for: {goal}", "agent": "qa", "dependencies": ["t2"]}
        ]
