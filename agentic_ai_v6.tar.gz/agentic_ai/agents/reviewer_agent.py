"""
Reviewer Agent: reviews generated code files.
Can APPROVE or REJECT with specific feedback.
"""

import os
import re
import json
from typing import Any, Dict
from agents.base_agent import BaseAgent


REVIEW_PROMPT_TEMPLATE = """<|system|>
You are a senior code reviewer. Review the provided Python code carefully.
Check for: correctness, completeness, obvious bugs, security issues.
Output ONLY a JSON object: {{"verdict": "APPROVE" or "REJECT", "feedback": "brief explanation"}}
<|user|>
Task that was implemented: {task_description}

Code to review:
```python
{code}
```

Output JSON only: {{"verdict": "APPROVE" or "REJECT", "feedback": "..."}}
<|assistant|>
"""


class ReviewerAgent(BaseAgent):
    def __init__(self, config: Dict, memory_store=None):
        super().__init__("Reviewer", config, memory_store)

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        task_id = task.get("task_id", "unknown")
        goal_id = task.get("goal_id", "unknown")
        description = task.get("description", "")
        file_path = task.get("file_path", "")

        self._log_action("review_start", {"task": description, "file": file_path},
                         goal_id=goal_id, task_id=task_id)

        code = self._read_file(file_path)
        if code is None:
            result = {
                "status": "error",
                "verdict": "REJECT",
                "feedback": f"Could not read file: {file_path}"
            }
            self._log_action("review_complete", result, goal_id=goal_id, task_id=task_id)
            return result

        prompt = REVIEW_PROMPT_TEMPLATE.format(
            task_description=description,
            code=code[:2000]  # Limit to avoid token overflow on small models
        )
        raw_output = self._generate(prompt)
        result = self._parse_verdict(raw_output)
        self._log_action("review_complete", result, goal_id=goal_id, task_id=task_id)
        return result

    def _read_file(self, path: str):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            self.logger.error(f"Cannot read {path}: {e}")
            return None

    def _parse_verdict(self, raw: str) -> Dict:
        match = re.search(r'\{.*?\}', raw, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(0))
                verdict = data.get("verdict", "").upper()
                feedback = data.get("feedback", "No feedback provided.")
                if verdict in ("APPROVE", "REJECT"):
                    return {
                        "status": "success",
                        "verdict": verdict,
                        "feedback": feedback
                    }
            except json.JSONDecodeError:
                pass

        # Fallback: look for keywords
        if "APPROVE" in raw.upper():
            return {"status": "success", "verdict": "APPROVE", "feedback": raw[:200]}
        return {"status": "success", "verdict": "APPROVE",
                "feedback": "Auto-approved: model output unclear, defaulting to approve."}
