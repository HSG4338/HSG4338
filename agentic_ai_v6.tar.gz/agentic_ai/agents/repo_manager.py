"""
Repo Manager Agent: controls filesystem writes and enforces permissions.
Prevents cross-agent path violations.
Handles git operations.
"""

import os
import shutil
import logging
from typing import Any, Dict, List, Optional
from agents.base_agent import BaseAgent


class RepoManagerAgent(BaseAgent):
    def __init__(self, config: Dict, memory_store=None, workspace: str = "workspace"):
        super().__init__("RepoManager", config, memory_store)
        self.workspace = os.path.abspath(workspace)
        self._allowed_paths = [self.workspace]
        os.makedirs(self.workspace, exist_ok=True)
        self._init_git()

    def _init_git(self):
        """Initialize git repo in workspace if not already initialized."""
        git_dir = os.path.join(self.workspace, ".git")
        if not os.path.exists(git_dir):
            try:
                import subprocess
                subprocess.run(["git", "init", self.workspace], capture_output=True, timeout=10)
                subprocess.run(
                    ["git", "config", "user.email", "agent@local"],
                    capture_output=True, cwd=self.workspace, timeout=10
                )
                subprocess.run(
                    ["git", "config", "user.name", "Agentic AI"],
                    capture_output=True, cwd=self.workspace, timeout=10
                )
                self.logger.info(f"Git initialized at: {self.workspace}")
            except Exception as e:
                self.logger.warning(f"Git init failed: {e}")

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        action = task.get("action", "commit")
        goal_id = task.get("goal_id", "unknown")

        if action == "commit":
            return self._commit(task, goal_id)
        elif action == "validate_path":
            return self._validate_path(task.get("path", ""), goal_id)
        elif action == "list_files":
            return self._list_workspace()
        else:
            return {"status": "error", "error": f"Unknown action: {action}"}

    def _commit(self, task: Dict, goal_id: str) -> Dict:
        message = task.get("message", f"Agent commit for goal {goal_id}")
        self._log_action("commit_start", {"message": message}, goal_id=goal_id)

        try:
            import subprocess
            subprocess.run(["git", "add", "."], capture_output=True, cwd=self.workspace, timeout=10)
            result = subprocess.run(
                ["git", "commit", "-m", message],
                capture_output=True, text=True, cwd=self.workspace, timeout=10
            )
            success = result.returncode == 0
            output = result.stdout + result.stderr

            result_data = {
                "status": "success" if success else "warning",
                "committed": success,
                "output": output[:500]
            }
            self._log_action("commit_complete", result_data, goal_id=goal_id)
            return result_data
        except Exception as e:
            err = {"status": "error", "error": str(e)}
            self._log_action("commit_error", err, goal_id=goal_id)
            return err

    def _validate_path(self, path: str, goal_id: str) -> Dict:
        abs_path = os.path.abspath(path)
        allowed = any(abs_path.startswith(p) for p in self._allowed_paths)
        return {"status": "success", "path": path, "allowed": allowed}

    def _list_workspace(self) -> Dict:
        files = []
        for root, dirs, filenames in os.walk(self.workspace):
            # Skip .git directory
            dirs[:] = [d for d in dirs if d != ".git"]
            for f in filenames:
                files.append(os.path.relpath(os.path.join(root, f), self.workspace))
        return {"status": "success", "files": files, "count": len(files)}

    def push_to_github(self, github_config: Dict) -> Dict:
        """Push workspace to GitHub using API and git."""
        token = github_config.get("token", "")
        username = github_config.get("username", "")
        repo_name = github_config.get("repo_name", "agentic-ai-system")

        if not token or not username:
            return {"status": "error", "error": "GitHub token and username required"}

        try:
            import requests
            # Create repo if it doesn't exist
            api_url = f"https://api.github.com/user/repos"
            headers = {
                "Authorization": f"token {token}",
                "Accept": "application/vnd.github.v3+json"
            }
            repo_payload = {
                "name": repo_name,
                "private": False,
                "auto_init": False
            }
            resp = requests.post(api_url, json=repo_payload, headers=headers, timeout=30)
            if resp.status_code not in (201, 422):  # 422 = already exists
                return {"status": "error", "error": f"GitHub API error: {resp.status_code} {resp.text}"}

            repo_url = f"https://{username}:{token}@github.com/{username}/{repo_name}.git"

            import subprocess
            subprocess.run(
                ["git", "remote", "remove", "origin"],
                capture_output=True, cwd=self.workspace
            )
            subprocess.run(
                ["git", "remote", "add", "origin", repo_url],
                capture_output=True, cwd=self.workspace, timeout=10
            )
            result = subprocess.run(
                ["git", "push", "-u", "origin", "main", "--force"],
                capture_output=True, text=True, cwd=self.workspace, timeout=60
            )

            public_url = f"https://github.com/{username}/{repo_name}"
            return {
                "status": "success",
                "repo_url": public_url,
                "output": result.stdout + result.stderr
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}
