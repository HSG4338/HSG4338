"""
Base Agent: shared functionality for all agents.
Handles logging, memory access, and model invocation.
"""

import logging
import os
import sys
from typing import Any, Dict, Optional

# Allow imports from project root
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


class BaseAgent:
    def __init__(self, name: str, config: Dict[str, Any], memory_store=None):
        self.name = name
        self.config = config
        self.memory = memory_store
        self.model_id = config.get("model_id", "TinyLlama/TinyLlama-1.1B-Chat-v1.0")
        self.max_new_tokens = config.get("max_new_tokens", 512)
        self.temperature = config.get("temperature", 0.3)
        self.logger = logging.getLogger(f"Agent.{name}")

    def _generate(self, prompt: str, max_new_tokens: Optional[int] = None,
                  temperature: Optional[float] = None) -> str:
        from models.model_manager import generate_text
        return generate_text(
            model_id=self.model_id,
            prompt=prompt,
            max_new_tokens=max_new_tokens or self.max_new_tokens,
            temperature=temperature or self.temperature
        )

    def _log_action(self, action: str, details: Dict, goal_id: Optional[str] = None,
                    task_id: Optional[str] = None):
        self.logger.info(f"[{self.name}] {action}: {details}")
        if self.memory:
            self.memory.log_event(
                event_type=action,
                agent=self.name,
                payload=details,
                goal_id=goal_id,
                task_id=task_id
            )

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError("Subclasses must implement run()")
