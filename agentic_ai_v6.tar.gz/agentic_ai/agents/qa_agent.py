"""
QA/Test Agent: generates test files and runs them via subprocess.
Produces structured pass/fail results.
"""

import os
import re
import json
import subprocess
import sys
from typing import Any, Dict
from agents.base_agent import BaseAgent


QA_PROMPT_TEMPLATE = """<|system|>
You are a Python QA engineer. Write pytest tests for the provided code.
Output ONLY a JSON object: {{"test_filename": "test_xxx.py", "test_code": "full pytest code here"}}
No explanation. No markdown. Only valid JSON.
<|user|>
Implementation file: {file_path}
Task that was implemented: {task_description}

Code:
```python
{code}
```

Write pytest tests. Output JSON only:
{{"test_filename": "test_implementation.py", "test_code": "import pytest\n..."}}
<|assistant|>
"""


class QAAgent(BaseAgent):
    def __init__(self, config: Dict, memory_store=None, workspace: str = "workspace"):
        super().__init__("QA", config, memory_store)
        self.workspace = os.path.abspath(workspace)

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        task_id = task.get("task_id", "unknown")
        goal_id = task.get("goal_id", "unknown")
        description = task.get("description", "")
        file_path = task.get("file_path", "")

        self._log_action("qa_start", {"task": description, "file": file_path},
                         goal_id=goal_id, task_id=task_id)

        code = self._read_file(file_path)
        if code is None:
            result = {"status": "error", "error": f"Cannot read: {file_path}", "passed": False}
            self._log_action("qa_complete", result, goal_id=goal_id, task_id=task_id)
            return result

        prompt = QA_PROMPT_TEMPLATE.format(
            file_path=file_path,
            task_description=description,
            code=code[:1500]
        )
        raw = self._generate(prompt)
        test_path = self._write_tests(raw, file_path)
        run_result = self._run_tests(test_path)

        result = {
            "status": "success",
            "test_file": test_path,
            "passed": run_result["passed"],
            "output": run_result["output"],
            "return_code": run_result["return_code"]
        }
        self._log_action("qa_complete", result, goal_id=goal_id, task_id=task_id)
        return result

    def _read_file(self, path: str):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            self.logger.error(f"Cannot read {path}: {e}")
            return None

    def _write_tests(self, raw: str, impl_path: str) -> str:
        test_code = None
        test_filename = "test_implementation.py"

        match = re.search(r'\{.*\}', raw, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(0))
                test_filename = data.get("test_filename", "test_implementation.py")
                test_code = data.get("test_code", "")
            except (json.JSONDecodeError, KeyError):
                pass

        if not test_code:
            # Extract a Python block
            code_match = re.search(r'```python\n(.*?)```', raw, re.DOTALL)
            if code_match:
                test_code = code_match.group(1)

        if not test_code:
            # Minimal fallback test
            module = os.path.splitext(os.path.basename(impl_path))[0]
            test_code = f"""# Auto-generated minimal test
import importlib.util
import os

def test_file_exists():
    assert os.path.exists(r"{impl_path}"), "Implementation file must exist"

def test_file_importable():
    spec = importlib.util.spec_from_file_location("module", r"{impl_path}")
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except SystemExit:
        pass  # Scripts that call sys.exit() are ok
"""

        test_path = os.path.join(self.workspace, test_filename)
        os.makedirs(os.path.dirname(test_path), exist_ok=True)
        with open(test_path, "w", encoding="utf-8") as f:
            f.write(test_code)
        return test_path

    def _run_tests(self, test_path: str) -> Dict:
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pytest", test_path, "-v", "--tb=short", "--timeout=30"],
                capture_output=True,
                text=True,
                timeout=60,
                cwd=self.workspace
            )
            passed = result.returncode == 0
            return {
                "passed": passed,
                "output": (result.stdout + result.stderr)[:3000],
                "return_code": result.returncode
            }
        except subprocess.TimeoutExpired:
            return {"passed": False, "output": "Test timed out", "return_code": -1}
        except Exception as e:
            return {"passed": False, "output": str(e), "return_code": -1}
