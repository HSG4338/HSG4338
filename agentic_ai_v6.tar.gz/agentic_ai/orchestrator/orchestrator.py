"""
Orchestrator: manages agent lifecycle, routes tasks, tracks state.
Runs the goal loop: Plan -> Develop -> Review -> QA -> Commit -> Memory -> Repeat.
Fully deterministic and inspectable via memory/logs.
"""

import os
import sys
import json
import time
import uuid
import logging
import logging.handlers
from typing import Any, Dict, Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from memory.memory_store import MemoryStore

try:
    import cli as _cli
    _HAS_CLI = True
except ImportError:
    _HAS_CLI = False

from agents.planner_agent import PlannerAgent
from agents.developer_agent import DeveloperAgent
from agents.reviewer_agent import ReviewerAgent
from agents.qa_agent import QAAgent
from agents.repo_manager import RepoManagerAgent


def _setup_logging(log_dir: str) -> logging.Logger:
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, "orchestrator.log")

    logger = logging.getLogger("Orchestrator")
    logger.setLevel(logging.DEBUG)

    # File handler
    fh = logging.handlers.RotatingFileHandler(log_file, maxBytes=5_000_000, backupCount=3)
    fh.setLevel(logging.DEBUG)

    # Console handler
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)

    fmt = logging.Formatter("%(asctime)s [%(name)s] %(levelname)s: %(message)s")
    fh.setFormatter(fmt)
    ch.setFormatter(fmt)

    if not logger.handlers:
        logger.addHandler(fh)
        logger.addHandler(ch)

    return logger


class Orchestrator:
    def __init__(self, config_path: str = "configs/config.json"):
        with open(config_path, "r") as f:
            self.config = json.load(f)

        sys_cfg = self.config["system"]
        self.log_dir = sys_cfg["log_dir"]
        self.max_retries = sys_cfg["max_retries"]
        self.retry_delay = sys_cfg["retry_delay_seconds"]
        self.max_iterations = sys_cfg["max_goal_iterations"]
        self.workspace = sys_cfg.get("workspace_dir", "workspace")

        self.logger = _setup_logging(self.log_dir)
        self.memory = MemoryStore(sys_cfg["memory_db"])

        # Initialize agents
        agent_cfgs = self.config["agents"]
        self.planner = PlannerAgent(agent_cfgs["planner"], self.memory)
        self.developer = DeveloperAgent(agent_cfgs["developer"], self.memory, self.workspace)
        self.reviewer = ReviewerAgent(agent_cfgs["reviewer"], self.memory)
        self.qa = QAAgent(agent_cfgs["qa"], self.memory, self.workspace)
        self.repo_manager = RepoManagerAgent({}, self.memory, self.workspace)

        self.logger.info("Orchestrator initialized.")

    def run_goal(self, goal: str) -> Dict[str, Any]:
        """
        Execute the full agent loop for a given goal.
        Returns final status dict.
        """
        goal_id = str(uuid.uuid4())[:8]
        self.logger.info(f"=== Starting goal [{goal_id}]: {goal} ===")
        if _HAS_CLI:
            _cli.kv("Goal ID", goal_id, value_color=_cli.C.MAGENTA)
        self.memory.create_goal(goal_id, goal)

        iteration = 0
        last_file_path = None

        while iteration < self.max_iterations:
            iteration += 1
            self.logger.info(f"--- Iteration {iteration}/{self.max_iterations} ---")
            if _HAS_CLI:
                _cli.section(f"Iteration {iteration} / {self.max_iterations}", _cli.C.CYAN)
            self.memory.update_goal(goal_id, status="running", iteration=iteration)

            # Step 1: Plan
            if _HAS_CLI:
                _sp = _cli.Spinner("Planner  decomposing goal", _cli.C.BLUE).start()
            plan_result = self._with_retry("Planner", lambda: self.planner.run({
                "goal": goal, "goal_id": goal_id
            }))
            if plan_result.get("status") != "success":
                if _HAS_CLI: _sp.stop(False, "Planner  failed to produce a plan")
                self.logger.error("Planning failed. Aborting.")
                break
            tasks = plan_result["tasks"]
            if _HAS_CLI:
                _sp.stop(True, f"Planner  produced {len(tasks)} task(s)")
            self.logger.info(f"Plan: {len(tasks)} tasks")

            # Step 2: Execute tasks in dependency order
            task_results = {}
            iteration_succeeded = True

            for t in tasks:
                task_id   = t.get("id", str(uuid.uuid4())[:6])
                agent_name = t.get("agent", "developer")
                description = t.get("description", "")

                deps = t.get("dependencies", [])
                if not all(task_results.get(d, {}).get("status") == "success" for d in deps):
                    self.logger.warning(f"Skipping task {task_id}: unmet dependencies")
                    if _HAS_CLI: _cli.warn(f"Skipping {task_id}: dependencies not met")
                    task_results[task_id] = {"status": "skipped"}
                    continue

                self.memory.create_task(task_id, goal_id, description, agent_name)

                if agent_name == "developer":
                    if _HAS_CLI:
                        _sp = _cli.Spinner("Developer  writing code", _cli.C.GREEN).start()
                    result = self._with_retry(f"Developer-{task_id}", lambda: self.developer.run({
                        "task_id": task_id, "goal_id": goal_id, "description": description
                    }))
                    if result.get("status") == "success":
                        last_file_path = result.get("file_path")
                        task_results[task_id] = result
                        if _HAS_CLI:
                            fname = result.get("filename", "file")
                            lines = result.get("lines", "?")
                            _sp.stop(True, f"Developer  wrote {fname}  ({lines} lines)")
                    else:
                        if _HAS_CLI: _sp.stop(False, "Developer  failed")

                elif agent_name == "reviewer" and last_file_path:
                    if _HAS_CLI:
                        _sp = _cli.Spinner("Reviewer   analysing code", _cli.C.YELLOW).start()
                    result = self._with_retry(f"Reviewer-{task_id}", lambda: self.reviewer.run({
                        "task_id": task_id, "goal_id": goal_id,
                        "description": description, "file_path": last_file_path
                    }))
                    task_results[task_id] = result
                    verdict = result.get("verdict", "?")
                    if _HAS_CLI:
                        fb = result.get("feedback", "")[:50]
                        if verdict == "APPROVE":
                            _sp.stop(True, "Reviewer   APPROVED")
                        else:
                            _sp.stop(False, f"Reviewer   REJECTED — {fb}")
                    if verdict == "REJECT":
                        self.logger.warning(f"Reviewer rejected: {result.get('feedback')}")
                        iteration_succeeded = False

                elif agent_name == "qa" and last_file_path:
                    if _HAS_CLI:
                        _sp = _cli.Spinner("QA         running tests", _cli.C.MAGENTA).start()
                    result = self._with_retry(f"QA-{task_id}", lambda: self.qa.run({
                        "task_id": task_id, "goal_id": goal_id,
                        "description": description, "file_path": last_file_path
                    }))
                    task_results[task_id] = result
                    passed = result.get("passed", False)
                    if _HAS_CLI:
                        _sp.stop(passed, f"QA         {'PASSED' if passed else 'FAILED'}")
                    if not passed:
                        self.logger.warning("QA tests failed. Will re-iterate.")
                        iteration_succeeded = False
                else:
                    task_results[task_id] = {"status": "skipped"}

                status = task_results.get(task_id, {}).get("status", "unknown")
                self.memory.update_task(task_id, status=status,
                                        result=str(task_results.get(task_id, {})))

            # Step 3: Repo Manager commit
            if _HAS_CLI:
                _sp = _cli.Spinner("RepoManager  committing changes", _cli.C.CYAN).start()
            commit_result = self.repo_manager.run({
                "action": "commit",
                "goal_id": goal_id,
                "message": f"Iteration {iteration}: {goal[:60]}"
            })
            commit_ok = commit_result.get("status") in ("success", "warning")
            if _HAS_CLI:
                _sp.stop(commit_ok, "RepoManager  committed")
            self.logger.info(f"Commit: {commit_result}")

            # Step 4: Check if we are done
            if iteration_succeeded and last_file_path:
                self.logger.info(f"Goal [{goal_id}] completed in {iteration} iteration(s).")
                self.memory.update_goal(goal_id, status="completed")
                return {
                    "status": "success",
                    "goal_id": goal_id,
                    "iterations": iteration,
                    "output_file": last_file_path,
                    "task_results": task_results
                }

            if _HAS_CLI:
                _cli.warn(f"Iteration {iteration} incomplete — retrying in {self.retry_delay}s...")
            self.logger.info(f"Iteration {iteration} incomplete. Will retry...")
            time.sleep(self.retry_delay)

        # Exceeded max iterations
        if _HAS_CLI:
            _cli.fail(f"Goal failed after {iteration} iteration(s).")
        self.logger.error(f"Goal [{goal_id}] failed after {iteration} iterations.")
        self.memory.update_goal(goal_id, status="failed")
        return {
            "status": "failed",
            "goal_id": goal_id,
            "iterations": iteration,
            "output_file": last_file_path
        }

    def _with_retry(self, label: str, fn) -> Dict:
        """Execute fn with retry logic."""
        for attempt in range(1, self.max_retries + 1):
            try:
                result = fn()
                return result
            except Exception as e:
                self.logger.warning(f"[{label}] attempt {attempt}/{self.max_retries} failed: {e}")
                if attempt < self.max_retries:
                    time.sleep(self.retry_delay)
        self.logger.error(f"[{label}] all retries exhausted.")
        return {"status": "error", "error": f"{label} failed after {self.max_retries} retries"}

    def get_status(self) -> Dict:
        """Return current system status snapshot."""
        return {
            "memory_summary": self.memory.get_summary(),
            "recent_events": self.memory.get_recent_events(20),
            "goals": self.memory.list_goals()
        }
