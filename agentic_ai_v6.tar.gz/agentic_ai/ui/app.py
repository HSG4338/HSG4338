"""
Flask UI for the Agentic AI System.
Dark moody theme. Vanilla JS only. No heavy frameworks.
"""

import os
import sys
import json
import threading
import subprocess

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from flask import Flask, render_template, request, jsonify, Response
from memory.memory_store import MemoryStore
from models.model_manager import list_cached_models, loaded_models

app = Flask(__name__)

# Load config
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "configs", "config.json")
with open(CONFIG_PATH) as f:
    config = json.load(f)

memory = MemoryStore(config["system"]["memory_db"])

# Track running goals
_running_goals: dict = {}


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/status")
def api_status():
    summary = memory.get_summary()
    goals = memory.list_goals()
    events = memory.get_recent_events(30)
    return jsonify({
        "summary": summary,
        "goals": goals,
        "recent_events": events,
        "loaded_models": loaded_models()
    })


@app.route("/api/goal", methods=["POST"])
def api_submit_goal():
    data = request.get_json()
    goal = data.get("goal", "").strip()
    if not goal:
        return jsonify({"status": "error", "error": "Goal cannot be empty"}), 400

    # Run orchestrator in background thread
    def run_in_background(goal_text):
        from orchestrator.orchestrator import Orchestrator
        orch = Orchestrator(CONFIG_PATH)
        result = orch.run_goal(goal_text)
        _running_goals[goal_text] = result

    thread = threading.Thread(target=run_in_background, args=(goal,), daemon=True)
    thread.start()
    _running_goals[goal] = {"status": "running"}

    return jsonify({"status": "accepted", "message": f"Goal submitted: {goal}"})


@app.route("/api/goals")
def api_goals():
    return jsonify(memory.list_goals())


@app.route("/api/events")
def api_events():
    limit = request.args.get("limit", 50, type=int)
    goal_id = request.args.get("goal_id", None)
    return jsonify(memory.query_events(goal_id=goal_id, limit=limit))


@app.route("/api/models")
def api_models():
    return jsonify({
        "cached": list_cached_models(),
        "loaded": loaded_models()
    })


@app.route("/api/logs")
def api_logs():
    log_path = os.path.join(os.path.dirname(__file__), "..", "logs", "orchestrator.log")
    try:
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        return jsonify({"lines": lines[-200:]})  # Last 200 lines
    except FileNotFoundError:
        return jsonify({"lines": ["No log file found yet."]})


@app.route("/api/setup", methods=["POST"])
def api_setup():
    """Trigger the install script."""
    install_script = os.path.join(os.path.dirname(__file__), "..", "install_dependencies.bat")
    if not os.path.exists(install_script):
        return jsonify({"status": "error", "error": "install_dependencies.bat not found"})
    try:
        subprocess.Popen(["cmd", "/c", install_script], creationflags=subprocess.CREATE_NEW_CONSOLE)
        return jsonify({"status": "success", "message": "Install script launched in new console."})
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)})


if __name__ == "__main__":
    ui_cfg = config["ui"]
    app.run(host=ui_cfg["host"], port=ui_cfg["port"], debug=ui_cfg["debug"])
