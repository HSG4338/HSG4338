"""Tests for MemoryStore."""
import os
import sys
import tempfile
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from memory.memory_store import MemoryStore


@pytest.fixture
def mem():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        yield MemoryStore(db_path)


def test_create_and_get_goal(mem):
    g = mem.create_goal("g1", "Build a calculator")
    assert g["id"] == "g1"
    assert g["description"] == "Build a calculator"
    assert g["status"] == "pending"


def test_update_goal_status(mem):
    mem.create_goal("g2", "Test goal")
    mem.update_goal("g2", status="completed")
    g = mem.get_goal("g2")
    assert g["status"] == "completed"


def test_log_and_query_events(mem):
    mem.log_event("test_event", "TestAgent", {"key": "value"}, goal_id="g3")
    events = mem.query_events(event_type="test_event")
    assert len(events) == 1
    assert events[0]["agent"] == "TestAgent"
    assert events[0]["payload"]["key"] == "value"


def test_create_and_get_task(mem):
    mem.create_goal("g4", "Goal for task test")
    t = mem.create_task("t1", "g4", "Write unit tests", "qa")
    assert t["id"] == "t1"
    assert t["agent_assigned"] == "qa"


def test_get_summary(mem):
    mem.create_goal("s1", "Summary test goal")
    s = mem.get_summary()
    assert "total_goals" in s
    assert s["total_goals"] >= 1


def test_list_goals_by_status(mem):
    mem.create_goal("p1", "Pending goal")
    mem.create_goal("c1", "Completed goal")
    mem.update_goal("c1", status="completed")
    pending = mem.list_goals(status="pending")
    completed = mem.list_goals(status="completed")
    assert any(g["id"] == "p1" for g in pending)
    assert any(g["id"] == "c1" for g in completed)
