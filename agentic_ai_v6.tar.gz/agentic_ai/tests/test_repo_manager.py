"""Tests for RepoManagerAgent path validation."""
import os
import sys
import tempfile
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from agents.repo_manager import RepoManagerAgent


@pytest.fixture
def repo(tmp_path):
    return RepoManagerAgent({}, workspace=str(tmp_path))


def test_validate_path_inside_workspace(repo):
    result = repo.run({
        "action": "validate_path",
        "path": os.path.join(repo.workspace, "some_file.py")
    })
    assert result["allowed"] is True


def test_validate_path_outside_workspace(repo):
    result = repo.run({
        "action": "validate_path",
        "path": "/etc/passwd"
    })
    assert result["allowed"] is False


def test_list_files_empty_workspace(repo):
    result = repo.run({"action": "list_files"})
    assert result["status"] == "success"
    assert isinstance(result["files"], list)


def test_commit_in_workspace(repo):
    # Write a file and commit
    test_file = os.path.join(repo.workspace, "hello.txt")
    with open(test_file, "w") as f:
        f.write("hello")
    result = repo.run({"action": "commit", "goal_id": "test123", "message": "test commit"})
    assert result["status"] in ("success", "warning")  # warning if nothing to commit
