"""
Demo validation test: CLI calculator.
This test CREATES a calculator module and validates it works correctly.
Run this as: pytest tests/test_demo_calculator.py -v
"""
import os
import sys
import tempfile
import importlib.util

# The calculator implementation we'll write and then test
CALCULATOR_CODE = '''
"""Simple CLI calculator with basic arithmetic operations."""
import sys
import argparse


def add(a: float, b: float) -> float:
    return a + b


def subtract(a: float, b: float) -> float:
    return a - b


def multiply(a: float, b: float) -> float:
    return a * b


def divide(a: float, b: float) -> float:
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


def calculate(operation: str, a: float, b: float) -> float:
    ops = {
        "add": add,
        "subtract": subtract,
        "multiply": multiply,
        "divide": divide
    }
    if operation not in ops:
        raise ValueError(f"Unknown operation: {operation}. Choose from: {list(ops.keys())}")
    return ops[operation](a, b)


def main():
    parser = argparse.ArgumentParser(description="CLI Calculator")
    parser.add_argument("operation", choices=["add", "subtract", "multiply", "divide"])
    parser.add_argument("a", type=float)
    parser.add_argument("b", type=float)
    args = parser.parse_args()
    result = calculate(args.operation, args.a, args.b)
    print(f"Result: {result}")
    return result


if __name__ == "__main__":
    main()
'''


def _get_calc_module():
    """Write calculator to temp file and import it."""
    tmpdir = tempfile.mkdtemp()
    calc_path = os.path.join(tmpdir, "calculator.py")
    with open(calc_path, "w") as f:
        f.write(CALCULATOR_CODE)
    spec = importlib.util.spec_from_file_location("calculator", calc_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


calc = _get_calc_module()


def test_add():
    assert calc.add(2, 3) == 5
    assert calc.add(-1, 1) == 0
    assert calc.add(0, 0) == 0


def test_subtract():
    assert calc.subtract(10, 4) == 6
    assert calc.subtract(0, 5) == -5


def test_multiply():
    assert calc.multiply(3, 4) == 12
    assert calc.multiply(-2, 3) == -6
    assert calc.multiply(0, 100) == 0


def test_divide():
    assert calc.divide(10, 2) == 5.0
    assert calc.divide(7, 2) == 3.5


def test_divide_by_zero():
    import pytest
    with pytest.raises(ValueError, match="Cannot divide by zero"):
        calc.divide(5, 0)


def test_calculate_dispatch():
    assert calc.calculate("add", 1, 2) == 3
    assert calc.calculate("multiply", 4, 5) == 20


def test_unknown_operation():
    import pytest
    with pytest.raises(ValueError, match="Unknown operation"):
        calc.calculate("modulo", 10, 3)


def test_large_numbers():
    assert calc.add(1_000_000, 2_000_000) == 3_000_000
    assert calc.multiply(1000, 1000) == 1_000_000


def test_float_precision():
    result = calc.add(0.1, 0.2)
    assert abs(result - 0.3) < 1e-10
