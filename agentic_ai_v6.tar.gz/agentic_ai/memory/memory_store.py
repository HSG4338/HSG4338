"""
Persistent memory system using SQLite.
Stores decisions, failures, revisions, agent actions, and timestamps.
Fully queryable via structured methods.
"""

import sqlite3
import json
import os
import time
from datetime import datetime
from typing import Optional, List, Dict, Any


class MemoryStore:
    def __init__(self, db_path: str = "memory/memory.db"):
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    agent TEXT NOT NULL,
                    goal_id TEXT,
                    task_id TEXT,
                    payload TEXT NOT NULL,
                    timestamp REAL NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS goals (
                    id TEXT PRIMARY KEY,
                    description TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    iteration INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY,
                    goal_id TEXT NOT NULL,
                    description TEXT NOT NULL,
                    agent_assigned TEXT,
                    status TEXT NOT NULL DEFAULT 'pending',
                    result TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (goal_id) REFERENCES goals(id)
                );

                CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);
                CREATE INDEX IF NOT EXISTS idx_events_agent ON events(agent);
                CREATE INDEX IF NOT EXISTS idx_events_goal ON events(goal_id);
                CREATE INDEX IF NOT EXISTS idx_tasks_goal ON tasks(goal_id);
            """)

    def log_event(self, event_type: str, agent: str, payload: Dict[str, Any],
                  goal_id: Optional[str] = None, task_id: Optional[str] = None):
        now = time.time()
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO events (event_type, agent, goal_id, task_id, payload, timestamp, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (event_type, agent, goal_id, task_id,
                 json.dumps(payload), now, datetime.utcnow().isoformat())
            )

    def create_goal(self, goal_id: str, description: str) -> Dict:
        now = datetime.utcnow().isoformat()
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO goals (id, description, status, iteration, created_at, updated_at) "
                "VALUES (?, ?, 'pending', 0, ?, ?)",
                (goal_id, description, now, now)
            )
        return self.get_goal(goal_id)

    def update_goal(self, goal_id: str, status: str = None, iteration: int = None):
        now = datetime.utcnow().isoformat()
        with self._connect() as conn:
            if status and iteration is not None:
                conn.execute(
                    "UPDATE goals SET status=?, iteration=?, updated_at=? WHERE id=?",
                    (status, iteration, now, goal_id)
                )
            elif status:
                conn.execute(
                    "UPDATE goals SET status=?, updated_at=? WHERE id=?",
                    (status, now, goal_id)
                )
            elif iteration is not None:
                conn.execute(
                    "UPDATE goals SET iteration=?, updated_at=? WHERE id=?",
                    (iteration, now, goal_id)
                )

    def get_goal(self, goal_id: str) -> Optional[Dict]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM goals WHERE id=?", (goal_id,)).fetchone()
            return dict(row) if row else None

    def list_goals(self, status: Optional[str] = None) -> List[Dict]:
        with self._connect() as conn:
            if status:
                rows = conn.execute("SELECT * FROM goals WHERE status=? ORDER BY created_at DESC", (status,)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM goals ORDER BY created_at DESC").fetchall()
            return [dict(r) for r in rows]

    def create_task(self, task_id: str, goal_id: str, description: str, agent: str) -> Dict:
        now = datetime.utcnow().isoformat()
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO tasks (id, goal_id, description, agent_assigned, status, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, 'pending', ?, ?)",
                (task_id, goal_id, description, agent, now, now)
            )
        return self.get_task(task_id)

    def update_task(self, task_id: str, status: str, result: Optional[str] = None):
        now = datetime.utcnow().isoformat()
        with self._connect() as conn:
            conn.execute(
                "UPDATE tasks SET status=?, result=?, updated_at=? WHERE id=?",
                (status, json.dumps(result) if result is not None else None, now, task_id)
            )

    def get_task(self, task_id: str) -> Optional[Dict]:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
            return dict(row) if row else None

    def get_tasks_for_goal(self, goal_id: str) -> List[Dict]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM tasks WHERE goal_id=? ORDER BY created_at", (goal_id,)).fetchall()
            return [dict(r) for r in rows]

    def query_events(self, event_type: Optional[str] = None, agent: Optional[str] = None,
                     goal_id: Optional[str] = None, limit: int = 100) -> List[Dict]:
        clauses = []
        params = []
        if event_type:
            clauses.append("event_type=?")
            params.append(event_type)
        if agent:
            clauses.append("agent=?")
            params.append(agent)
        if goal_id:
            clauses.append("goal_id=?")
            params.append(goal_id)
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT * FROM events {where} ORDER BY timestamp DESC LIMIT ?",
                params
            ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            try:
                d["payload"] = json.loads(d["payload"])
            except Exception:
                pass
            result.append(d)
        return result

    def get_recent_events(self, limit: int = 50) -> List[Dict]:
        return self.query_events(limit=limit)

    def get_summary(self) -> Dict:
        with self._connect() as conn:
            total_goals = conn.execute("SELECT COUNT(*) FROM goals").fetchone()[0]
            completed = conn.execute("SELECT COUNT(*) FROM goals WHERE status='completed'").fetchone()[0]
            failed = conn.execute("SELECT COUNT(*) FROM goals WHERE status='failed'").fetchone()[0]
            total_events = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            total_tasks = conn.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        return {
            "total_goals": total_goals,
            "completed_goals": completed,
            "failed_goals": failed,
            "total_events": total_events,
            "total_tasks": total_tasks
        }
